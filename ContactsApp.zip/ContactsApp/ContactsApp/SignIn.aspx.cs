﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace ContactsApp
{
    public partial class SignIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                lblMsg.Text = "";
                lblError.Text = "";
                if (ValidateInputs())
                {
                    if (IsValidEmail())
                    {
                        using (SqlConnection conn = new SqlConnection())
                        {
                            string strEmail = txtEmail.Text;
                            string strPassword = txtPassword.Text;
                            string strSecret = txtScret.Text;
                            string Connection = ConfigurationManager.AppSettings["Connection"];
                            conn.ConnectionString = Connection;
                            conn.Open();
                            DataTable dt = new DataTable();
                            var sqlQuery = "select * from Login where Email='" + strEmail + "'";
                            using (SqlCommand cmd = new SqlCommand(sqlQuery, conn))
                            {
                                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                                ad.Fill(dt);
                            }
                            if (dt.Rows.Count > 0)
                            {
                                lblError.Text = "Email Id is existed!";
                            }
                            else
                            {
                                string sql = "INSERT INTO Login (Email,Password,Secret) VALUES ('" + strEmail + "','" + strPassword + "','" + strSecret + "')";
                                SqlCommand cmd1 = new SqlCommand(sql, conn);
                                cmd1.CommandType = CommandType.Text;
                                cmd1.ExecuteNonQuery();
                            }
                        }
                    }
                    else
                    {
                        lblError.Text = "Invalid Email!";
                    }
                    
                }
                else
                {
                    lblError.Text = "Enter all fields!";
                }

                txtPassword.Text = "";
                txtEmail.Text = "";
                txtScret.Text = "";
                lblMsg.Text = "Sign Up successful. You can Sing In now.";
            }
            catch (Exception )
            {
                lblError.Text = "Sorry for inconvience cause. There is some error while Sign Up. Please try after sometime";
            }
        }

        public bool ValidateInputs()
        {
            bool flag = true;
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                flag = false;
            }
            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                flag = false;
            }
            if (string.IsNullOrEmpty(txtScret.Text))
            {
                flag = false;
            }
            return flag;
        }
        public bool IsValidEmail()
        {
            var r = new Regex(@"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[com]{2,9})$");

            return !string.IsNullOrEmpty(txtEmail.Text) && r.IsMatch(txtEmail.Text);
        }
    }
}