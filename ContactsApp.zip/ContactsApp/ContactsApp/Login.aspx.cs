﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;


namespace ContactsApp
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                
                lblError.Text = "";
                if (ValidateInputs())
                {
                    using (SqlConnection conn = new SqlConnection())
                    {
                        string strEmail = txtEmail.Text;
                        string strPassword = txtPassword.Text;
                        string Connection = ConfigurationManager.AppSettings["Connection"];
                        conn.ConnectionString = Connection;
                        conn.Open();
                        DataTable dt = new DataTable();                        
                        var sqlQuery = "select * from Login where Email='" + strEmail + "' and Password='" + strPassword + "'";
                        using (SqlCommand cmd = new SqlCommand(sqlQuery, conn))
                        {
                            SqlDataAdapter ad = new SqlDataAdapter(cmd);
                            ad.Fill(dt);
                        }
                        if (dt.Rows.Count > 0)
                        {
                            Response.Redirect("Contact.aspx");
                        }
                        else
                        {
                            lblError.Text = "Invalid Email and Password!";
                        }
                    }

                }
                else
                {
                    lblError.Text = "Enter Email and Password!";
                }

                txtPassword.Text = "";
                txtEmail.Text = "";
            }
            catch (Exception)
            {
                lblError.Text = "Sorry for inconvience cause. There is some error while Sign In. Please try after sometime";
            }
        }

        public bool ValidateInputs()
        {
            bool flag = true;
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                flag = false;
            }
            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                flag = false;
            }

            return flag;
        }
    }
}