﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace ContactsApp
{
    public partial class Contact : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                lblMsg.Text = "";
                lblError.Text = "";
                if (ValidateInputs())
                {
                    if (IsValidEmail())
                    {
                        using (SqlConnection conn = new SqlConnection())
                        {
                            string strName = txtName.Text;
                            string strPhone = txtPhone.Text;
                            string strEmail = txtEmail.Text;
                            string Connection = ConfigurationManager.AppSettings["Connection"];
                            conn.ConnectionString = Connection;
                            conn.Open();
                            string sql = "INSERT INTO Contact (Name,Phone,Email) VALUES ('" + strName + "','" + strPhone + "','" + strEmail + "')";
                            SqlCommand cmd1 = new SqlCommand(sql, conn);
                            cmd1.CommandType = CommandType.Text;
                            cmd1.ExecuteNonQuery();
                            conn.Close();
                            BindContact();
                        }
                    }
                    else
                    {
                        lblError.Text = "Invalid Email!";
                    }

                }
                else
                {
                    lblError.Text = "Enter all fields!";
                }

                txtName.Text = "";
                txtEmail.Text = "";
                txtPhone.Text = "";
                lblMsg.Text = "Contact added successfully!";
            }
            catch (Exception)
            {
                lblError.Text = "Failed to add contact info!";
            }
        }

        public void BindContact()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    string strName = txtName.Text;
                    string strPhone = txtPhone.Text;
                    string strEmail = txtEmail.Text;
                    string Connection = ConfigurationManager.AppSettings["Connection"];
                    conn.ConnectionString = Connection;
                    conn.Open();
                    string sql = "select * from Contact";
                    DataTable dt = new DataTable();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        SqlDataAdapter ad = new SqlDataAdapter(cmd);
                        ad.Fill(dt);
                    }
                    SqlCommand cmd1 = new SqlCommand(sql, conn);
                    cmd1.CommandType = CommandType.Text;
                    cmd1.ExecuteNonQuery();
                    conn.Close();
                    gdvContact.DataSource = dt;
                    gdvContact.DataBind();
                }
            }
            catch (Exception)
            {
                lblError.Text = "Problem in displaying my contacts";
            }
        }

        public bool ValidateInputs()
        {
            bool flag = true;
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                flag = false;
            }
            if (string.IsNullOrEmpty(txtPhone.Text))
            {
                flag = false;
            }
            if (string.IsNullOrEmpty(txtName.Text))
            {
                flag = false;
            }
            return flag;
        }

        public bool IsValidEmail()
        {
            var r = new Regex(@"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[com]{2,9})$");

            return !string.IsNullOrEmpty(txtEmail.Text) && r.IsMatch(txtEmail.Text);
        }
    }
}